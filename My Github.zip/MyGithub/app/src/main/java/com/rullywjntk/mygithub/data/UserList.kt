package com.rullywjntk.mygithub.data

class UserList(
    val items: ArrayList<User>
)