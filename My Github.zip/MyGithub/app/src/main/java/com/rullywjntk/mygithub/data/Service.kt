package com.rullywjntk.mygithub.data

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface Service {

    @GET("search/users")
    @Headers("Authorization: token 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")
    fun getQuery(
        @Query("q") query: String
    ):Call<UserList>

    @GET("users/{username}")
    @Headers("Authorization: token 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")
    fun userDetail(
        @Path("username") username: String
    ):Call<UserDetail>

    @GET("users/{username}/followers")
    @Headers("Authorization: token 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")
    fun getFollowers(
        @Path("username") username: String
    ):Call<ArrayList<User>>

    @GET("users/{username}/following")
    @Headers("Authorization: token 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")
    fun getFollowing(
        @Path("username") username: String
    ):Call<ArrayList<User>>

}