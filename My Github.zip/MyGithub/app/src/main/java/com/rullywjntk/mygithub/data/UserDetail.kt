package com.rullywjntk.mygithub.data

data class UserDetail(
    val id: Int,
    val login: String,
    val avatar_url: String,
    val name: String,
    val followers_url: String,
    val following_url: String,
    val public_repos: Int,
    val location: String,
    val company: String,
    val followers: Int,
    val following: Int
)